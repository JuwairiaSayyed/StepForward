package com.example.signup_1;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class cateogory extends AppCompatActivity {
    Button covidpatient,volunteer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cateogory);

        covidpatient=(Button)findViewById(R.id.covidpatient);
        volunteer=(Button)findViewById(R.id.volunteer);

        covidpatient.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(cateogory.this,patients1.class);
                startActivity(intent);
            }
        });

        volunteer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(cateogory.this,volunteers1.class);
                startActivity(intent);
            }
        });
    }
}