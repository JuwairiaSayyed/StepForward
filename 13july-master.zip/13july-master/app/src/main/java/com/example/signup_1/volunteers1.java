package com.example.signup_1;

import androidx.appcompat.app.AppCompatActivity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class volunteers1 extends AppCompatActivity implements View.OnClickListener {

    EditText vname,vage,vcon,vemail,servicesp;
    Button s1,sv;
    SQLiteDatabase dbv;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_volunteers);

        vname = (EditText) findViewById(R.id.vname);
        vage = (EditText) findViewById(R.id.vage);
        vcon = (EditText) findViewById(R.id.vcon);
        vemail = (EditText) findViewById(R.id.vemail);
        servicesp=(EditText)findViewById(R.id.servicesp);
        s1 = (Button)findViewById(R.id.s1);
        sv= (Button)findViewById(R.id.sv);

        s1.setOnClickListener(this);
        sv.setOnClickListener(this);

        dbv=openOrCreateDatabase("VolunteersDB", Context.MODE_PRIVATE, null);
        dbv.execSQL("CREATE TABLE IF NOT EXISTS voln(name VARCHAR,age VARCHAR,con VARCHAR,servicespro Varchar,email Varchar);");

    }

    public void onClick(View v) {
        if(v==s1)
        {
            // Checking for empty fields
            if(vname.getText().toString().trim().length()==0||
                    vage.getText().toString().trim().length()==0||
                    vcon.getText().toString().trim().length()==0||
                    servicesp.getText().toString().trim().length()==0||
                    vemail.getText().toString().trim().length()==0)
            {
                showMessage("Error", "Please enter all values");
                return;
            }
            dbv.execSQL("INSERT INTO voln VALUES('"+vname.getText()+"','"+vage.getText()+
                    "','"+vcon.getText()+"','"+servicesp.getText()+"','"+vemail.getText()+"');");
            showMessage("Success", "Details saved");
            clearText();
        }

        if(v==sv)
        {
            Cursor c=dbv.rawQuery("SELECT * FROM voln", null);
            if(c.getCount()==0)
            {
                showMessage("Error", "No records found");
                return;
            }
            StringBuffer buffer=new StringBuffer();
            while(c.moveToNext())
            {
                buffer.append("Name: "+c.getString(0)+"\n");
                buffer.append("Age: "+c.getString(1)+"\n");
                buffer.append("Contact: "+c.getString(2)+"\n\n");
                buffer.append("Services Provides: "+c.getString(3)+"\n\n");
                buffer.append("Email Address: "+c.getString(4)+"\n\n");
            }
            showMessage("Volunteer Details", buffer.toString());
        }
    }

    public void showMessage(String title,String message)
    {
        AlertDialog.Builder builder=new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }

    public void clearText()
    {
        vname.setText("");
        vage.setText("");
        vcon.setText("");
        vemail.setText("");
        servicesp.setText("");
    }

}
